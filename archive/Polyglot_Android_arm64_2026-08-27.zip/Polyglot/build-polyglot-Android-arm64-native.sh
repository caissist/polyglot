#!/data/data/com.termux/files/usr/bin/bash
# PolyGlot 2.0.4-ut-4 – Android ARM64 native – Moto g84
set -e

SRC="$HOME/src/polyglot-thiel"
cd "$SRC"

make clean >/dev/null 2>&1 || true
rm -f ./*.o polyglot config.log config.status
rm -rf .deps

./configure \
  CC=clang \
  CFLAGS="-O3 -pipe -march=native -flto -std=gnu99" \
  LDFLAGS="-flto"

make -j"$(nproc)"

file ./polyglot
sha256sum ./polyglot
